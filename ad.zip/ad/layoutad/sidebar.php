<?php
include 'config.php';
?>


<body>

    <div class="d-flex" id="wrapper">
        
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <div class="sidebar-heading text-white">
                <i class="fas fa-hand-holding-heart me-2 text-primary"></i> GiveSphere
            
             <button id="sidebar-close" class="btn text-white d-md-none">
            <i class="fas fa-times fa-lg"></i>
        </button>
        </div>
            <div class="list-group list-group-flush mt-3">
                <a href="index.php" class="list-group-item list-group-item-action active">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
                <a href="donation.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-donate me-2"></i> Donations
                </a>
                <a href="volunteer.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-users me-2"></i> Volunteers
                </a>
                <a href="event.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-calendar-alt me-2"></i> Events
                </a>
                <a href="contactus.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-envelope me-2"></i> Contact <span class="badge bg-danger rounded-pill ms-2"></span>
                </a>
                 <a href="users.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-envelope me-2"></i> User <span class="badge bg-danger rounded-pill ms-2"></span>
                </a>
                 <a href="signin.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-envelope me-2"></i> sign in<span class="badge bg-danger rounded-pill ms-2"></span>
                </a>
                <a href="setting.php" class="list-group-item list-group-item-action">
                    <i class="fas fa-cog me-2"></i> Settings
                </a>
                <a href="logout.php" class="list-group-item list-group-item-action mt-5 text-danger">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
            </div>
        </div>

        <!-- Page Content -->
        <div id="page-content-wrapper">
            
            <!-- Top Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light bg-white">
                <div class="container-fluid">
                    <button class="btn btn-primary" id="menu-toggle"><i class="fas fa-bars"></i></button>

                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mt-2 mt-lg-0 align-items-center">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                    data-bs-toggle="dropdown">
                                    <img src="https://ui-avatars.com/api/?name=Admin+User&background=0d6efd&color=fff" class="rounded-circle" width="40" alt="Admin">
                                    <span class="ms-2 fw-bold">Himanshu</span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end shadow border-0" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                                    <li><a class="dropdown-item" href="setting.php">Settings</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
