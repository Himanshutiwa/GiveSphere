<?php
$con = mysqli_connect('localhost', 'root', '', 'givesphere');

?>