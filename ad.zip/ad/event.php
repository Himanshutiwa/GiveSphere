<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Management - Charity Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>

   <?php
    include 'layoutad/sidebar.php';
   ?>
            <div class="container-fluid px-4 py-4">

                <!-- Header Section -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h3 class="fw-bold text-dark">Events Management</h3>
                        <p class="text-muted">Manage upcoming charity drives and fundraisers.</p>
                    </div>
                    <button class="btn btn-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addEventModal">
                        <i class="fas fa-plus me-2"></i> Create New Event
                    </button>
                </div>

                <!-- Event Stats (Optional) -->
                <div class="row mb-4 g-3">
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm p-3 d-flex flex-row align-items-center">
                            <div class="bg-primary text-white rounded-circle p-3 me-3"><i class="fas fa-calendar-alt"></i></div>
                            <div>
                                <h5 class="mb-0">12</h5><small class="text-muted">Upcoming Events</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm p-3 d-flex flex-row align-items-center">
                            <div class="bg-success text-white rounded-circle p-3 me-3"><i class="fas fa-check"></i></div>
                            <div>
                                <h5 class="mb-0">45</h5><small class="text-muted">Completed</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Events Grid -->
                <div class="row g-4">

                    <!-- Event Card 1 -->
                    <div class="col-md-6 col-lg-4">
                        <div class="card event-card h-100">
                            <div class="event-img-container">
                                <img src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                                    alt="Event">
                                <div class="date-badge">
                                    <span class="d-block small text-muted">DEC</span>
                                    <span class="fs-5">15</span>
                                </div>
                                <div class="position-absolute bottom-0 start-0 m-3">
                                    <span class="badge bg-warning text-dark"><i class="fas fa-clock"></i> Upcoming</span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title fw-bold">Charity Winter Gala</h5>
                                <p class="text-muted small mb-3"><i class="fas fa-map-marker-alt me-1 text-danger"></i> Grand
                                    Hall, New York</p>

                                <!-- Fundraising Progress -->
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span class="text-muted">Raised: <strong>$12,000</strong></span>
                                        <span class="text-muted">Goal: $20,000</span>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 60%"></div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center mt-3 border-top pt-3">
                                    <div class="avatars">
                                        <!-- Small avatars of volunteers -->
                                        <img src="https://ui-avatars.com/api/?name=A&background=random"
                                            class="rounded-circle border border-white" width="30">
                                        <img src="https://ui-avatars.com/api/?name=B&background=random"
                                            class="rounded-circle border border-white ms-n2" width="30"
                                            style="margin-left: -10px;">
                                        <small class="ms-2 text-muted">+12 Volunteers</small>
                                    </div>
                                    <div>
                                        <a href="#" class="btn-action btn-edit"><i class="fas fa-pen"></i></a>
                                        <a href="#" class="btn-action btn-delete"><i class="fas fa-trash"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Event Card 2 -->
                    <div class="col-md-6 col-lg-4">
                        <div class="card event-card h-100">
                            <div class="event-img-container">
                                <img src="https://images.unsplash.com/photo-1593113598340-0687199726ce?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                                    alt="Event">
                                <div class="date-badge">
                                    <span class="d-block small text-muted">DEC</span>
                                    <span class="fs-5">20</span>
                                </div>
                                <div class="position-absolute bottom-0 start-0 m-3">
                                    <span class="badge bg-primary"><i class="fas fa-running"></i> Registration Open</span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title fw-bold">Run for Education 2023</h5>
                                <p class="text-muted small mb-3"><i class="fas fa-map-marker-alt me-1 text-danger"></i> Central
                                    Park, NYC</p>

                                <!-- Fundraising Progress -->
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span class="text-muted">Raised: <strong>$5,400</strong></span>
                                        <span class="text-muted">Goal: $10,000</span>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 54%"></div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center mt-3 border-top pt-3">
                                    <div>
                                        <small class="text-muted"><i class="fas fa-users me-1"></i> 150 Participants</small>
                                    </div>
                                    <div>
                                        <a href="#" class="btn-action btn-edit"><i class="fas fa-pen"></i></a>
                                        <a href="#" class="btn-action btn-delete"><i class="fas fa-trash"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Event Card 3 (Completed) -->
                    <div class="col-md-6 col-lg-4">
                        <div class="card event-card h-100 opacity-75"> <!-- Slightly faded because it's done -->
                            <div class="event-img-container">
                                <img src="https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                                    alt="Event">
                                <div class="date-badge bg-light">
                                    <span class="d-block small text-muted">NOV</span>
                                    <span class="fs-5">10</span>
                                </div>
                                <div class="position-absolute bottom-0 start-0 m-3">
                                    <span class="badge bg-secondary"><i class="fas fa-check-circle"></i> Completed</span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title fw-bold">Clean Water Drive</h5>
                                <p class="text-muted small mb-3"><i class="fas fa-map-marker-alt me-1 text-danger"></i> Austin,
                                    Texas</p>

                                <div class="mb-3">
                                    <div class="d-flex justify-content-between small mb-1">
                                        <span class="text-success fw-bold">Goal Reached!</span>
                                        <span class="text-muted">$50k / $50k</span>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%"></div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center mt-3 border-top pt-3">
                                    <div><small class="text-muted">Impact: 2000 Families</small></div>
                                    <div>
                                        <a href="#" class="btn-action btn-light border"><i class="fas fa-eye"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div> <!-- End Row -->

            </div>

            <!-- Add Event Modal -->
            <div class="modal fade" id="addEventModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0 shadow">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title"><i class="fas fa-calendar-plus me-2"></i> Add New Event</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="mb-3">
                                    <label class="form-label">Event Title</label>
                                    <input type="text" class="form-control" placeholder="Ex: Charity Gala">
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Date</label>
                                        <input type="date" class="form-control">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Time</label>
                                        <input type="time" class="form-control">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Location</label>
                                    <input type="text" class="form-control" placeholder="Ex: City Hall">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Fundraising Goal ($)</label>
                                    <input type="number" class="form-control" placeholder="10000">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Cover Image</label>
                                    <input type="file" class="form-control">
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Save Event</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Scripts -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>